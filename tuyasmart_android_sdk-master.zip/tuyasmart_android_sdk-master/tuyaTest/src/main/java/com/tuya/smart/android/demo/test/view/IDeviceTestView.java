package com.tuya.smart.android.demo.test.view;

/**
 * Created by letian on 16/7/11.
 */
public interface IDeviceTestView {
    void log(String log);
}
