package com.tuya.smart.android.demo.model.firmware;

/**
 * Created by letian on 16/4/20.
 */
public interface IUpgradeTimeOutModel {
    void start();

    void setProgressTime();
}
