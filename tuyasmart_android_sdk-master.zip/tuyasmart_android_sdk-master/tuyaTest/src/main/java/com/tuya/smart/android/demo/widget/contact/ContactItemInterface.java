package com.tuya.smart.android.demo.widget.contact;

public interface ContactItemInterface {

    String getItemForIndex();

    String getNumber();

    String getKey();
}
