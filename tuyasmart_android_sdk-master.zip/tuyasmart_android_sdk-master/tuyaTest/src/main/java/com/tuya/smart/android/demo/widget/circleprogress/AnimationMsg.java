package com.tuya.smart.android.demo.widget.circleprogress;

enum AnimationMsg {

   START_SPINNING,
   STOP_SPINNING,
   SET_VALUE,
   SET_VALUE_ANIMATED,
   TICK

}
