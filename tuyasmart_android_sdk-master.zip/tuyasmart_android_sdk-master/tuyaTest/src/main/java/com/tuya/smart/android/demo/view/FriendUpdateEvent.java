package com.tuya.smart.android.demo.view;


import com.tuya.smart.android.demo.event.FriendEventModel;

/**
 * Created by letian on 15/6/2.
 */
public interface FriendUpdateEvent {
    void onEvent(FriendEventModel event);
}
