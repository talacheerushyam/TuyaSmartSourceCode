package com.tuya.smart.android.demo.test.bean;

/**
 * Created by letian on 15/6/23.
 */
public class AlertPickerResult {
    private String selectedKey;

    public String getSelectedKey() {
        return selectedKey;
    }

    public void setSelectedKey(String selectedKey) {
        this.selectedKey = selectedKey;
    }
}
