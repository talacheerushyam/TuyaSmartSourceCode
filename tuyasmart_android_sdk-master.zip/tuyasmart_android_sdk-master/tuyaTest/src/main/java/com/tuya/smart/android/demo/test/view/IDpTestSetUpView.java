package com.tuya.smart.android.demo.test.view;

import com.tuya.smart.android.demo.test.bean.DpTestSetUpBean;

/**
 * Created by letian on 16/8/6.
 */
public interface IDpTestSetUpView {
    DpTestSetUpBean getSetData();
}
