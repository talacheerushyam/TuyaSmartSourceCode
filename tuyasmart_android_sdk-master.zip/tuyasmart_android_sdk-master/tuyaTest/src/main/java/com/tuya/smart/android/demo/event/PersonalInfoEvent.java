package com.tuya.smart.android.demo.event;



/**
 * Created by letian on 15/6/22.
 */
public interface PersonalInfoEvent {
    void onEvent(PersonalInfoEventModel event);
}
