package com.tuya.smart.android.demo.widget.contact;

public class ContactItemException extends Exception {

    public ContactItemException() {
    }

    public ContactItemException(String msg) {
        super(msg);
    }


}
