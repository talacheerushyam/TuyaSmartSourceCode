package com.tuya.smart.android.demo.test.event;

/**
 * Created by letian on 16/7/12.
 */
public interface DpSendDataEvent {
    void onEvent(DpSendDataModel model);
}
