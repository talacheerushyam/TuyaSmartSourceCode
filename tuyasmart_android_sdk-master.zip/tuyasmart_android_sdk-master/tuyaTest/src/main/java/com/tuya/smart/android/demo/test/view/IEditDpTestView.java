package com.tuya.smart.android.demo.test.view;

/**
 * Created by letian on 16/7/12.
 */
public interface IEditDpTestView {
    void log(String tag);

    void clearLog();
}
